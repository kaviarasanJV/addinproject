const devCerts = require("office-addin-dev-certs");
const CopyWebpackPlugin = require("copy-webpack-plugin");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const webpack = require("webpack");

const urlDev = "https://localhost:3000/";
const urlProd = "https://metadact365addin.z13.web.core.windows.net/"; // CHANGE THIS TO YOUR PRODUCTION DEPLOYMENT LOCATION

async function getHttpsOptions() {
  const httpsOptions = await devCerts.getHttpsServerOptions();
  return { ca: httpsOptions.ca, key: httpsOptions.key, cert: httpsOptions.cert };
}

const backendDev = "https://localhost:5001/clean/api/v1.0/";
const backendProd = "https://dev-metadatacleanapi.literadev.com/clean/api/v1.0/";

module.exports = async (env, options) => {
  const dev = options.mode === "development";
  const buildType = dev ? "dev" : "prod";
  const config = {
    devtool: "source-map",
    entry: {
      polyfill: ["core-js/stable", "regenerator-runtime/runtime"],
      vendor: ["react", "react-dom", "core-js"],
      index: "./index.ts",
      taskpane: ["react-hot-loader/patch", "./src/taskpane/taskpane.tsx"],
      dialog: ["react-hot-loader/patch", "./src/dialog/dialog.tsx"],
      launchevent: "./src/launchevent/launchevent.ts",
    },
    output: {
      devtoolModuleFilenameTemplate: "webpack:///[resource-path]?[loaders]",
      clean: true,
    },
    resolve: {
      extensions: [".ts", ".tsx", ".html", ".js"],
    },
    module: {
      rules: [
        {
          test: /\.tsx?$/,
          use: ["react-hot-loader/webpack", "ts-loader"],
          exclude: /node_modules/,
        },
        {
          test: /\.css$/,
          use: ["style-loader", "css-loader"],
        },
        {
          test: /\.(png|jpg|jpeg|gif)$/,
          loader: "file-loader",
          options: {
            name: "[path][name].[ext]",
          },
        },
      ],
    },
    plugins: [
      new CopyWebpackPlugin({
        patterns: [
          {
            to: "dialog.css",
            from: "./src/dialog/dialog.css",
          },
          {
            to: "collapsible.css",
            from: "./src/dialog/collapsible.css",
          },
          {
            to: "taskpane.css",
            from: "./src/taskpane/taskpane.css",
          },
          {
            to: "[name]." + buildType + "[ext]",
            from: "manifest*.xml",
            transform(content) {
              content = content.toString().replace(new RegExp("{{version}}", "g"), process.env.version);

              if (dev) {
                return content;
              } else {
                return content.replace(new RegExp(urlDev, "g"), urlProd);
              }
            },
          },
          {
            to: "config.json",
            from: "./src/config.json",
            transform(content) {
              if (dev) {
                return content;
              } else {
                return content.toString().replace(new RegExp(backendDev, "g"), backendProd);
              }
            },
          },
          {
            to: "assets",
            from: "./assets/",
          },
        ],
      }),
      new HtmlWebpackPlugin({
        filename: "index.html",
        template: "./index.html",
        chunks: ["index","launchevent"],
      }),
      new HtmlWebpackPlugin({
        filename: "dialog.html",
        template: "./src/dialog/dialog.html",
        chunks: ["dialog", "vendor", "polyfills"],
      }),
      new HtmlWebpackPlugin({
        filename: "taskpane.html",
        template: "./src/taskpane/taskpane.html",
        chunks: ["taskpane", "vendor", "polyfills"],
      }),
      new webpack.ProvidePlugin({
        Promise: ["es6-promise", "Promise"],
      }),
    ],
    devServer: {
      hot: true,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      server: {
        type: "https",
        options: env.WEBPACK_BUILD || options.https !== undefined ? options.https : await getHttpsOptions(),
      },
      port: process.env.npm_package_config_dev_server_port || 3000,
    },
  };

  return config;
};
