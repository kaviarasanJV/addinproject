import * as React from "react";
import { TextField, Stack } from "@fluentui/react";
import translation from "../../utils/translation";
import { DialogAction } from "../../types";

interface IButtonsProps {
  sendMessage(message: string): void;
  attachmentId: string;
  passwordError?: boolean;
  passwordIncorrect?: boolean;
}

const enterCharCode = 13;

export const PasswordInput: React.FunctionComponent<IButtonsProps> = ({
  sendMessage,
  attachmentId,
  passwordError,
  passwordIncorrect,
}: IButtonsProps): React.ReactElement => {
  const [value, setValue] = React.useState("");

  const handleChange = (e) => {
    setValue(e.target.value);
  };

  const validatePassword = (e) => {
    if (e.type === "blur") {
      sendMessage(JSON.stringify({ password: value, attachmentId: attachmentId, action: DialogAction.GetPassword }));
    } else if (e.type === "keypress" && e!.charCode === enterCharCode) {
      e.target.blur();
    }
  };

  return (
    <Stack horizontal verticalAlign={"center"}>
      <TextField
        type="password"
        placeholder={translation.passwordPlaceholder}
        value={value}
        onKeyPress={validatePassword}
        onBlur={validatePassword}
        onChange={handleChange}
        disabled={passwordError === false}
        errorMessage={passwordIncorrect && translation.passwordNotCorrect}
      />
    </Stack>
  );
};
