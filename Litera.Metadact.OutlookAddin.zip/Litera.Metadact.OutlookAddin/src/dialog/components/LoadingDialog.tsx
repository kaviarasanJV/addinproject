import * as React from "react";
import { Spinner, SpinnerSize, Stack } from "@fluentui/react";
import translation from "../../utils/translation";

const Dialog = () => (
  <Stack verticalFill horizontalAlign="center" verticalAlign="center">
    <Spinner label={translation.dialogLoading} size={SpinnerSize.large} />
  </Stack>
);

export default Dialog;
