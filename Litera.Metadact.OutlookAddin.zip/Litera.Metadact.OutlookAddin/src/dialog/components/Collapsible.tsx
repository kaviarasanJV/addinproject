import React, { useMemo, useRef, useState } from "react";
import { Icon } from "@fluentui/react/lib/Icon";
import { Link } from "@fluentui/react";

function getTextWidth(text, font) {
  // re-use canvas object for better performance
  const canvas = document.createElement("canvas");
  const context = canvas.getContext("2d");
  context.font = font;
  const metrics = context.measureText(text);
  return metrics.width;
}

export function Collapsible(props: { message: string; onDismiss: any }) {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const memoisedResult = useMemo(() => {
    return getTextWidth(props.message, "bold 9pt Segoe UI");
  }, [props.message]);
  console.log(memoisedResult);

  return (
    <div className="collapsible-container">
      <div style={{ marginLeft: 4 }}>
        <Icon iconName="Error" className="error-icon" />
      </div>
      <div
        className="collapsible-text-container"
        onClick={() => {
          setIsCollapsed(!isCollapsed);
        }}
      >
        <div className={isCollapsed ? "collapsed" : "opened"} ref={containerRef}>
          {props.message}
        </div>
        {isCollapsed && memoisedResult > containerRef?.current?.clientWidth && (
          <>
            <Link title="read more">read more</Link>
          </>
        )}
        {!isCollapsed && memoisedResult > containerRef?.current?.clientWidth && (
          <>
            <Link title="read less">read less</Link>
          </>
        )}
      </div>
      <div>
        <Icon
          iconName="Cancel"
          className="cancel-icon"
          onClick={() => {
            props.onDismiss();
          }}
        />
      </div>
    </div>
  );
}
