import * as React from "react";
import { Stack, IStackTokens, PrimaryButton } from "@fluentui/react";
import translation from "../../utils/translation";

export interface IButtonsProps {
  onSendButtonClick: () => void;
  onCancelButtonClick: () => void;
  disabledSend?: boolean;
  checkedSend?: boolean;
  disabledCancel?: boolean;
  checkedCancel?: boolean;
}

const stackTokens: IStackTokens = {
  childrenGap: 10,
  maxWidth: "100%",
};

export const ButtonGroup: React.FunctionComponent<IButtonsProps> = ({
  onSendButtonClick,
  onCancelButtonClick,
  checkedSend,
  checkedCancel,
  disabledCancel,
  disabledSend,
}: IButtonsProps): React.ReactElement => (
  <Stack horizontal horizontalAlign="end" verticalAlign="center" tokens={stackTokens}>
    <PrimaryButton
      text={translation.send}
      onClick={onSendButtonClick}
      allowDisabledFocus
      disabled={disabledSend}
      checked={checkedSend}
      title={disabledSend ? translation.tooltipSendDisabled : ""}
    />
    <PrimaryButton
      text={translation.cancel}
      onClick={onCancelButtonClick}
      allowDisabledFocus
      disabled={disabledCancel}
      checked={checkedCancel}
    />
  </Stack>
);
