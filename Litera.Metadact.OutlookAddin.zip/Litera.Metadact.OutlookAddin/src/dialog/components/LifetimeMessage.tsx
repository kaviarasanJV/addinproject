import * as React from "react";
import { MessageBar, MessageBarType } from "@fluentui/react";

import { formatSeconds } from "../../utils/utils";
import translation from "../../utils/translation";

type LifetimeMessageProps = {
  timerValue: number;
};

const LifetimeMessage = ({ timerValue }: LifetimeMessageProps) => (
  <MessageBar messageBarType={MessageBarType.info}>
    <b>{`${translation.warningDialogLifetime} ${formatSeconds(timerValue)}`}</b>
  </MessageBar>
);

export default LifetimeMessage;
