import * as React from "react";
import {
  DetailsList,
  DetailsListLayoutMode,
  IDetailsListProps,
  IDetailsRowProps,
  DetailsRow,
  SelectionMode,
  IColumn,
  Icon,
  TooltipHost,
  Shimmer,
  IComboBoxOption,
  ProgressIndicator,
} from "@fluentui/react";
import { getFileTypeIconProps, initializeFileTypeIcons } from "@fluentui/react-file-type-icons";
import { PasswordInput } from "./PasswordInput";
import { ComboBoxControlled } from "./ComboBoxControlled";
import translation from "../../utils/translation";
import { CleaningOption } from "../../types";
import usePrev from "../../hooks/usePrev";
import { mergeStyleSets } from "@fluentui/react/lib/Styling";
import { IAttachment } from "../../core/interfaces/IAttachment";

initializeFileTypeIcons();
const classNames = mergeStyleSets({
  fileIconHeaderIcon: {
    padding: 0,
    fontSize: "16px",
  },
  cellField: {
    display: "flex!important",
    alignItems: "center",
  },
  fileIconImg: {
    verticalAlign: "middle",
    maxHeight: "16px",
    maxWidth: "16px",
  },
  fileNameWrapper: {
    display: "flex",
  },
  fileName: {
    marginRight: "4px",
    whiteSpace: "nowrap",
    overflow: "hidden",
    textOverflow: "ellipsis",
  },
  high: {
    backgroundColor: "#f2dede",
    ":hover": {
      backgroundColor: "#f2dede",
    },
  },
  medium: {
    backgroundColor: "#fcf8e3",
    ":hover": {
      backgroundColor: "#fcf8e3",
    },
  },
  low: {
    backgroundColor: "#dff0d8",
    ":hover": {
      backgroundColor: "#dff0d8",
    },
  },
});

interface IDetailsListDocumentsProps {
  sendMessage(message: string): void;
  attachments: Array<IAttachment>;
  onChangeAttachmentOption(attachmentID: string, attachmentOption: string | number): void;
  disabledOptions: boolean;
  globalCleaningOption: string;
  rawOptions: CleaningOption[];
}

interface IDocument {
  key: string;
  name: string;
  value: string;
  typeIconOptions: { iconName: string };
  fileType: string;
  contentRisk: string;
  riskLevel: string;
  passwordError?: boolean;
  option: string;
  errorMsg: string;
  error: boolean;
  passwordIncorrect: boolean;
  progress: number;
}

function _generateDocuments(
  attachments: IAttachment[],
  prevAttachments: IAttachment[],
  globalCleaningOption: string,
  onChangeAttachmentOption: (attachmentID: string, attachmentOption: string | number) => void
) {
  const itemsWithoutRiskCalculation: IDocument[] = [];
  const passwordNeededItem: IDocument[] = [];
  const corruptedFileItem: IDocument[] = [];
  const cloudFilesItem: IDocument[] = [];
  const highRiskItem: IDocument[] = [];
  const mediumRiskItem: IDocument[] = [];
  const lowRiskItem: IDocument[] = [];

  attachments.forEach((attachment) => {
    const FileType = _getFileIcon(attachment.name);
    const fileName = attachment.name;
    const prevAttachment = prevAttachments?.find(({ id: prevId }) => attachment.id === prevId);
    const isPasswordAcquired = prevAttachment && prevAttachment.passwordError && !attachment.passwordError;

    const item = {
      key: attachment.id,
      name: fileName,
      value: fileName,
      typeIconOptions: FileType.typeIconOptions,
      fileType: FileType.docType,
      contentRisk: attachment.contentRisk || "",
      riskLevel: attachment.riskLevel || "",
      passwordError: attachment.passwordError,
      option: attachment.option,
      errorMsg: attachment.errorMsg,
      error: attachment.error,
      passwordIncorrect: attachment.passwordIncorrect,
      progress: attachment.progress,
    };

    if (isPasswordAcquired) {
      item.option = globalCleaningOption;
      onChangeAttachmentOption(item.key, globalCleaningOption);
    }

    switch (item.riskLevel) {
      case translation.notAvailable:
        passwordNeededItem.push(item);
        break;
      case translation.corruptedFile:
        corruptedFileItem.push(item);
        break;
      case translation.notSupported:
        cloudFilesItem.push(item);
        break;
      case translation.high:
        highRiskItem.push(item);
        break;
      case translation.medium:
        mediumRiskItem.push(item);
        break;
      case translation.low:
        lowRiskItem.push(item);
        break;
      default:
        itemsWithoutRiskCalculation.push(item);
    }
  });
  return [
    ...sortItems(passwordNeededItem),
    ...sortItems(corruptedFileItem),
    ...sortItems(cloudFilesItem),
    ...sortItems(highRiskItem),
    ...sortItems(mediumRiskItem),
    ...sortItems(lowRiskItem),
    ...sortItems(itemsWithoutRiskCalculation),
  ];
}

function sortItems(items: IDocument[]): IDocument[] {
  return items?.sort((a, b) => (a.name > b.name ? 1 : -1));
}

function _getFileIcon(name: string): { docType: string; typeIconOptions: { iconName: string } } {
  const regName = name.split(".");
  const ext = regName[regName.length - 1];
  const typeIconOptions = getFileTypeIconProps({ extension: ext, size: 16 });
  return {
    docType: ext,
    typeIconOptions: typeIconOptions,
  };
}

function _isPasswordRequired(attachment): boolean {
  return attachment.passwordError === true;
}

export default function DetailsListDocuments({
  attachments,
  onChangeAttachmentOption,
  sendMessage,
  disabledOptions,
  globalCleaningOption,
  rawOptions,
}: IDetailsListDocumentsProps) {
  const _getKey = (item: any): string => {
    return item.key;
  };

  const columnsData: IColumn[] = [
    {
      key: "icon",
      name: translation.fileTypeName,
      className: classNames.cellField,
      iconClassName: classNames.fileIconHeaderIcon,
      ariaLabel: translation.fileTypeDescription,
      iconName: "Page",
      isIconOnly: true,
      fieldName: "icon",
      minWidth: 16,
      maxWidth: 16,
      onRender: function iconComponent(item: IDocument) {
        return (
          <TooltipHost content={`${item.fileType} file`}>
            <Icon {...item.typeIconOptions} />
          </TooltipHost>
        );
      },
    },
    {
      key: "name",
      name: translation.fileName,
      className: classNames.cellField,
      fieldName: "name",
      minWidth: 100,
      maxWidth: 200,
      isRowHeader: true,
      isResizable: true,
      data: "string",
      isPadded: true,
      onRender: function nameComponent(item: IDocument) {
        const passwordError = _isPasswordRequired(item);

        const attachmentError = item.error;

        return (
          <div className={classNames.fileNameWrapper}>
            <TooltipHost hostClassName={classNames.fileName} content={item.name}>
              {item.name.slice(0, 15) + (item.name.length > 15 ? "..." : "")}
            </TooltipHost>
            {attachmentError && (
              <TooltipHost content={item.errorMsg}>
                <Icon iconName="Warning" />
              </TooltipHost>
            )}
            {passwordError && (
              <TooltipHost content={translation.passwordRequired}>
                <Icon iconName="Lock" />
              </TooltipHost>
            )}
          </div>
        );
      },
    },
    {
      key: "cleaningOption",
      name: translation.cleaningOption,
      className: classNames.cellField,
      fieldName: "cleaningOption",
      minWidth: 100,
      maxWidth: 150,
      isRowHeader: true,
      isResizable: true,
      data: "string",
      isPadded: true,
      onRender: function comboBoxControlledComponent(item: IDocument) {
        const passwordError = _isPasswordRequired(item);

        return (
          <ComboBoxControlled
            attachmentOption={item.option}
            attachmentId={item.key}
            disabled={passwordError || item.error || disabledOptions}
            onChangeAttachmentOption={onChangeAttachmentOption}
            options={options}
          />
        );
      },
    },
    {
      key: "riskLevel",
      name: translation.riskLevel,
      className: classNames.cellField,
      fieldName: "riskLevel",
      minWidth: 70,
      maxWidth: 90,
      isResizable: true,
      data: "string",
      onRender: function riskLevelComponent(item: IDocument) {
        return (
          <Shimmer isDataLoaded={!!item.riskLevel}>
            <TooltipHost content={item.riskLevel}>{item.riskLevel}</TooltipHost>
          </Shimmer>
        );
      },
      isPadded: true,
    },
    {
      key: "contentRisk",
      name: translation.contentRisk,
      className: classNames.cellField,
      fieldName: "contentRisk",
      minWidth: 70,
      maxWidth: 90,
      isResizable: true,
      data: "string",
      onRender: function contentRiskComponent(item: IDocument) {
        if (_isPasswordRequired(item)) {
          return (
            <PasswordInput
              sendMessage={sendMessage}
              attachmentId={item.key}
              passwordError={item.passwordError}
              passwordIncorrect={item.passwordIncorrect}
            />
          );
        }
        return (
          <Shimmer isDataLoaded={!!item.riskLevel}>
            <TooltipHost content={item.contentRisk}>{item.contentRisk}</TooltipHost>
          </Shimmer>
        );
      },
      isPadded: true,
    },
  ];

  const prevAttachments = usePrev(attachments);
  const options: IComboBoxOption[] = React.useMemo(
    () =>
      rawOptions.map(({ profileName, caption }) => ({
        text: caption,
        key: profileName,
      })),
    [rawOptions]
  );

  const [items, setItems] = React.useState<IDocument[]>(() =>
    _generateDocuments(attachments, prevAttachments, globalCleaningOption, onChangeAttachmentOption)
  );
  const [columns, setColumns] = React.useState(columnsData);

  React.useEffect(() => {
    setColumns(columnsData);
    setItems(_generateDocuments(attachments, prevAttachments, globalCleaningOption, onChangeAttachmentOption));
  }, [attachments]);

  React.useEffect(() => {
    setColumns(columnsData);
  }, [disabledOptions]);

  const _onRenderRow: IDetailsListProps["onRenderRow"] = (props: IDetailsRowProps) => {
    if (props.item) {
      let className = [
        translation.high,
        translation.notSupported,
        translation.notAvailable,
        translation.corruptedFile,
        translation.danger,
      ].includes(props.item.riskLevel)
        ? classNames.high
        : props.item.riskLevel == translation.medium
        ? classNames.medium
        : props.item.riskLevel == translation.low
        ? classNames.low
        : "";

      return (
        <>
          <DetailsRow {...props} className={className} />
          <ProgressIndicator percentComplete={props.item.progress} progressHidden={props.item.progress == 1} />
        </>
      );
    }
    return null;
  };

  return (
    <DetailsList
      items={items}
      columns={columns}
      selectionMode={SelectionMode.none}
      getKey={_getKey}
      setKey="none"
      layoutMode={DetailsListLayoutMode.justified}
      isHeaderVisible={true}
      onRenderRow={_onRenderRow}
      compact={true}
    />
  );
}
