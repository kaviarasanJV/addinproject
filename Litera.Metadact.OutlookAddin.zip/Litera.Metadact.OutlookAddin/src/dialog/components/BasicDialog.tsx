import * as React from "react";
import DetailsListDocuments from "./DetailsListDocuments";
import { ChoiceGroupControlled } from "./ChoiceGroupControlled";
import { ButtonGroup } from "./ButtonGroup";
import LifetimeMessage from "./LifetimeMessage";
import translation from "../../utils/translation";

import {
  IStackItemStyles,
  Stack,
  MessageBar,
  MessageBarType,
  ProgressIndicator,
  IStackTokens,
  Separator,
} from "@fluentui/react";
import { DialogAction, Config } from "../../types";
import useDialogTimer from "../../hooks/useDialogTimer";
import { getCacheConfig } from "../../core/Cache";
import { getProfiles } from "../../core/MetadactApi";
import { getMappedProfileOptions } from "../../utils/utils";
import { IAttachment } from "../../core/interfaces/IAttachment";
import { Collapsible } from "./Collapsible";

export interface DialogProps {
  attachments: Array<IAttachment>;
  emailsWarnArray: string[];
  sendMessage(message: string): void;
  loadingPercent?: number;
  error: {
    errorMessage: string;
    order: number;
  };
  onChangeAttachmentOption(attachmentID: string, attachmentOption: string | number): void;
  onChangeOption(option: string): void;
}

const stackItemStyles: IStackItemStyles = {
  root: {
    overflow: "auto",
  },
};

const stackItemStylesTable: IStackItemStyles = {
  root: {
    maxHeight: "79%",
  },
};

const stackStyles: IStackItemStyles = {
  root: {
    height: "calc(100% - 8px)",
  },
};

const stackButtonStyles: IStackItemStyles = {
  root: {
    width: "100%",
  },
};

const stackWarningtyles: IStackItemStyles = {
  root: {
    width: "100%",
    maxHeight: "20%",
    overflow: "auto",
  },
};

const stackSeparatorStyles: IStackItemStyles = {
  root: {
    margin: "0",
    padding: "0",
  },
};

const themedSmallStackTokens: IStackTokens = {
  childrenGap: "s1",
};

export default function Dialog({
  attachments,
  emailsWarnArray,
  sendMessage,
  error,
  loadingPercent,
  onChangeAttachmentOption,
  onChangeOption,
}: DialogProps) {
  const [config, setConfig] = React.useState<Config>(null);
  const [errors, setErrors] = React.useState([]);
  const [isSending, setIsSending] = React.useState(false);
  const [percentComplete, setPercentComplete] = React.useState(0);
  const [reportProgress, setReportProgress] = React.useState(0);
  const [isWarn, setІsWarn] = React.useState(false);
  const [globalCleaningOption, setGlobalCleaningOption] = React.useState<string>(null);
  const [_profilesOptions, setProfilesOptions] = React.useState([]);

  const timerValue = useDialogTimer(sendMessage);

  const onDismissError = (index) => {
    errors.splice(index, 1);
    setErrors([...errors]);
  };

  const onSendButtonClick = () => {
    setIsSending(true);
    sendMessage(JSON.stringify({ action: DialogAction.Send, dialogAttachments: attachments }));
  };

  const onCancelButtonClick = () => {
    sendMessage(JSON.stringify({ action: DialogAction.CloseDialog }));
  };

  const disabledSend = !attachments.every((attachment) => !!attachment.riskLevel) || isSending;

  React.useEffect(() => {
    const processConfig = async () => {
      const result = await getCacheConfig();
      setConfig(result);
      setGlobalCleaningOption(result.defaultOption || result.options[0].id);
    };

    processConfig();
  }, []);

  React.useEffect(() => {
    const processConfig = async () => {
      const profiles = await getProfiles();
      const result = await getCacheConfig();
      // map the information id from the server to local options
      const mappedProfileOptions = getMappedProfileOptions(profiles.parsedBody, result.options);
      setProfilesOptions(mappedProfileOptions ?? []);
    };

    processConfig();
  }, []);

  React.useEffect(() => {
    setІsWarn(emailsWarnArray.length > 0 ? true : false);
  }, [emailsWarnArray]);

  React.useEffect(() => {
    if (error.errorMessage) {
      if (errors.filter((value) => value.errorMessage == error.errorMessage).length > 0) {
        return;
      }
      let intermediate = [...errors, { ...error }];
      intermediate.sort(function (a, b) {
        return a.order - b.order;
      });
      setErrors(JSON.parse(JSON.stringify(intermediate)));
    }
    setIsSending(false);
  }, [error]);

  React.useEffect(() => {
    setPercentComplete(loadingPercent);
  }, [loadingPercent]);

  React.useEffect(() => {
    setReportProgress(attachments.filter((item) => item.progress === 1).length);
  }, [attachments]);

  const passwordWarningArray = attachments.filter((attachment) => attachment.passwordError === true);

  if (!config) return <ProgressIndicator />;

  return (
    <Stack verticalFill styles={stackStyles} tokens={themedSmallStackTokens}>
      {timerValue !== null && <LifetimeMessage timerValue={timerValue} />}

      <Stack>
        {(isWarn || passwordWarningArray.length > 0) && (
          <Stack.Item className="warningStack" align="end" styles={stackWarningtyles}>
            <MessageBar messageBarType={MessageBarType.severeWarning}>
              {emailsWarnArray && emailsWarnArray.length > 0 && (
                <Stack.Item>
                  {translation.warningRiskEmail}&nbsp;
                  {emailsWarnArray.length > 1 ? translation.addresses : translation.address}:
                  <ul>
                    {emailsWarnArray.map((email) => (
                      <li key={email}>
                        {email} - {translation.riskyDomain}
                      </li>
                    ))}
                  </ul>
                </Stack.Item>
              )}

              {passwordWarningArray.length > 0 && (
                <Stack.Item>
                  {translation.passwordWarningPartOne}
                  <ul>
                    {passwordWarningArray.map((attachment) => (
                      <li key={attachment.name}>{attachment.name}</li>
                    ))}
                  </ul>
                  {translation.passwordWarningPartTwo}
                </Stack.Item>
              )}
            </MessageBar>
          </Stack.Item>
        )}
      </Stack>
      
      {Boolean(errors.length) &&
        errors.map((item, index) => (
          <>
            {/* <MessageBar
              messageBarType={MessageBarType.error}
              onDismiss={() => {
                return onDismissError(index);
              }}
              dismissButtonAriaLabel={translation.close}
              truncated={true}
              key={index}
            >
              <b>{item.errorMessage}</b>
            </MessageBar> */}
            <Collapsible
              message={`${item.errorMessage}`}
              onDismiss={() => {
                return onDismissError(index);
              }}
              key={String(index)}
            />
          </>
        ))}
      <Stack grow styles={stackItemStylesTable}>
        <Stack.Item grow styles={stackItemStyles}>
          <DetailsListDocuments
            attachments={attachments}
            sendMessage={sendMessage}
            onChangeAttachmentOption={onChangeAttachmentOption}
            disabledOptions={disabledSend}
            globalCleaningOption={globalCleaningOption}
            rawOptions={_profilesOptions}
          />
        </Stack.Item>
        <Separator styles={stackSeparatorStyles} />
        <ProgressIndicator
          description={
            reportProgress === 0
              ? `${attachments.length} files processing`
              : ` ${reportProgress} / ${attachments.length} processed`
          }
          percentComplete={reportProgress / attachments.length}
          progressHidden={reportProgress == attachments.length}
        />

        <ChoiceGroupControlled
          onChangeOption={onChangeOption}
          disabledOption={disabledSend}
          rawOptions={_profilesOptions}
          setGlobalCleaningOption={setGlobalCleaningOption}
          globalCleaningOption={globalCleaningOption}
        />
      </Stack>

      <Stack.Item className="buttonGroup" align="end" styles={stackButtonStyles}>
        <Stack horizontal verticalAlign="center" tokens={themedSmallStackTokens}>
          <Stack.Item grow>
            {isSending && <ProgressIndicator description={translation.cleaning} percentComplete={percentComplete} />}
          </Stack.Item>
          <Stack.Item>
            <ButtonGroup
              onSendButtonClick={onSendButtonClick}
              onCancelButtonClick={onCancelButtonClick}
              disabledSend={disabledSend}
            />
          </Stack.Item>
        </Stack>
      </Stack.Item>
    </Stack>
  );
}
