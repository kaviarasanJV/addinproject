import * as React from "react";
import { ComboBox, IComboBoxOption, IComboBox, TooltipHost, mergeStyleSets } from "@fluentui/react";

import translation from "../../utils/translation";

const classNames = mergeStyleSets({
  comboBox: {
    "& *": {
      border: "none",
      backgroundColor: "transparent!important",
    },
    "& *::after": {
      display: "none",
    },
  },
});

export interface IComboBoxControlledControlledProps {
  onChangeAttachmentOption(attachmentId: string, attachmentOption: string | number): void;
  attachmentId: string;
  attachmentOption: string;
  disabled: boolean;
  options: IComboBoxOption[];
}

export const ComboBoxControlled: React.FunctionComponent<IComboBoxControlledControlledProps> = ({
  onChangeAttachmentOption,
  attachmentId,
  attachmentOption,
  disabled,
  options,
}: IComboBoxControlledControlledProps) => {
  const [selectedKey, setSelectedKey] = React.useState<string | number>(attachmentOption);

  React.useEffect(() => {
    setSelectedKey(attachmentOption);
  }, [attachmentOption]);

  const onChange = React.useCallback((_ev: React.FormEvent<IComboBox>, option?: IComboBoxOption): void => {
    onChangeAttachmentOption(attachmentId, option.key);
    setSelectedKey(option.key);
  }, []);

  return (
    <TooltipHost content={disabled ? translation.tooltipOptionPasswordDisabled : ""}>
      <ComboBox
        autoComplete="on"
        options={options}
        selectedKey={selectedKey}
        onChange={onChange}
        disabled={disabled}
        className={classNames.comboBox}
      />
    </TooltipHost>
  );
};
