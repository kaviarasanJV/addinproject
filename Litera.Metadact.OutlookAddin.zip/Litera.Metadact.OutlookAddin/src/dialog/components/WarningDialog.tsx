import * as React from "react";
import { ButtonGroup } from "./ButtonGroup";
import { Stack, MessageBar, MessageBarType, IStackTokens, IStackItemStyles } from "@fluentui/react";
import translation from "../../utils/translation";
import { DialogAction } from "../../types";
import useDialogTimer from "../../hooks/useDialogTimer";
import LifetimeMessage from "./LifetimeMessage";

export interface DialogProps {
  emailsWarnArray: string[];
  sendMessage(message: string): void;
}

const stackStyles: IStackItemStyles = {
  root: {
    height: "calc(100% - 8px)",
  },
};

const themedSmallStackTokens: IStackTokens = {
  childrenGap: "s1",
};

const stackButtomStyles: IStackItemStyles = {
  root: {
    width: "100%",
  },
};

export default function WarningDialog({ sendMessage, emailsWarnArray }: DialogProps) {
  const timerValue = useDialogTimer(sendMessage);

  const onSendButtonClick = () => {
    sendMessage(JSON.stringify({ action: DialogAction.Send }));
  };

  const onCancelButtonClick = () => {
    sendMessage(JSON.stringify({ action: DialogAction.CloseDialog }));
  };

  return (
    <Stack verticalFill styles={stackStyles} tokens={themedSmallStackTokens}>
      {timerValue !== null && (
        <Stack.Item grow>
          <LifetimeMessage timerValue={timerValue} />
        </Stack.Item>
      )}
      <Stack.Item grow>
        <MessageBar messageBarType={MessageBarType.severeWarning}>
          {translation.warningRiskEmail}&nbsp;
          {emailsWarnArray.length > 1 ? translation.addresses : translation.address}:
          <ul>
            {emailsWarnArray.map((email) => (
              <li key={email}>
                {email} - {translation.riskyDomain}
              </li>
            ))}
          </ul>
        </MessageBar>
      </Stack.Item>
      <Stack.Item align="end" styles={stackButtomStyles}>
        <ButtonGroup onSendButtonClick={onSendButtonClick} onCancelButtonClick={onCancelButtonClick} />
      </Stack.Item>
    </Stack>
  );
}
