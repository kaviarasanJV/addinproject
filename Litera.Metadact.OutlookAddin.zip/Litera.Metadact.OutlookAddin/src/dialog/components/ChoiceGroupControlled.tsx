import * as React from "react";
import { ChoiceGroup, IChoiceGroupOption, IChoiceGroupStyles, TooltipHost } from "@fluentui/react";
import translation from "../../utils/translation";
import { CleaningOption } from "../../types";

const optionClass: IChoiceGroupStyles = {
  flexContainer: {
    display: "flex",
    flexDirection: "column",
    flexWrap: "wrap",
    maxHeight: "110px",
  },
};

export interface IChoiceGroupControlledProps {
  onChangeOption(option: string): void;
  disabledOption: boolean;
  rawOptions: CleaningOption[];
  setGlobalCleaningOption: (options: string) => void;
  globalCleaningOption: string;
}

export const ChoiceGroupControlled: React.FunctionComponent<IChoiceGroupControlledProps> = ({
  onChangeOption,
  disabledOption,
  rawOptions,
  setGlobalCleaningOption,
  globalCleaningOption,
}: IChoiceGroupControlledProps) => {
  const [options, setOptions] = React.useState<IChoiceGroupOption[]>();

  React.useEffect(() => {
    setOptions(
      rawOptions.map(({ profileName, caption }) => ({
        text: caption,
        key: profileName,
        disabled: disabledOption,
      }))
    );
  }, [rawOptions]);

  React.useEffect(() => {
    setOptions((choices) => {
      return choices.map((option) => ({ ...option, disabled: disabledOption }));
    });
  }, [disabledOption]);

  const onChange = React.useCallback((_ev: React.SyntheticEvent<HTMLElement>, option: IChoiceGroupOption) => {
    onChangeOption(option.key);
    setGlobalCleaningOption(option.key);
  }, []);

  return (
    <TooltipHost content={disabledOption ? translation.tooltipOptionDisabled : ""}>
      <ChoiceGroup
        styles={optionClass}
        selectedKey={globalCleaningOption}
        options={options}
        onChange={onChange}
        label={translation.cleaningOptions}
      />
    </TooltipHost>
  );
};
