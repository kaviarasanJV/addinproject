import BasicDialog from "./components/BasicDialog";
import WarningDialog from "./components/WarningDialog";
import LoadingDialog from "./components/LoadingDialog";
import { AppContainer } from "react-hot-loader";
import { initializeIcons } from "@fluentui/react/lib/Icons";
import * as React from "react";
import * as ReactDOM from "react-dom";

initializeIcons();

//TODO change to state
let attachments = [];
let loadingPercent = 0;
let error = { errorMessage: "" };
let emailsWarnArray = [];
let isWarningDialog = false;

const render = (Component) => {
  ReactDOM.render(
    <AppContainer>
      <Component
        sendMessage={sendMessage}
        attachments={attachments}
        loadingPercent={loadingPercent}
        error={error}
        emailsWarnArray={emailsWarnArray}
        onChangeOption={onChangeOption}
        onChangeAttachmentOption={onChangeAttachmentOption}
      />
    </AppContainer>,
    document.getElementById("container")
  );
};

const onChangeOption = (option) => {
  attachments = attachments.map((attachment) =>
    attachment.error === true || attachment.passwordError === true ? attachment : { ...attachment, option: option }
  );
  render(BasicDialog);
};

const onChangeAttachmentOption = (attachmentId, attachmentOption) => {
  attachments = attachments.map((attachment) =>
    attachment.id === attachmentId ? { ...attachment, option: attachmentOption } : attachment
  );
  render(BasicDialog);
};

const messageHandler = (payload) => {
  // console.log("Message received from dialog parent", payload);
  const data = JSON.parse(payload.message);
  if (data.attachmentArray) {
    attachments = data.attachmentArray;
  }
  if (data.attachment) {
    const newAttachment = data.attachment;
    attachments = attachments.map((oldAttachment) =>
      oldAttachment.id === newAttachment.id ? newAttachment : oldAttachment
    );
  }
  if (data.loadingPercent) {
    loadingPercent = data.loadingPercent;
  }
  if (data.error) {
    error = data.error;
  }
  if (data.emailsWarnArray) {
    emailsWarnArray = data.emailsWarnArray;
  }
  if (data.isWarningDialog) {
    isWarningDialog = true;
  }

  //Todo remove multiple render
  if (isWarningDialog) {
    render(WarningDialog);
  } else {
    render(BasicDialog);
  }
};

const sendMessage = (message) => {
  console.log("Message send to dialog parent", message);
  Office.context.ui.messageParent(message);
};

Office.onReady().then(function () {
  render(LoadingDialog);
  Office.context.ui.addHandlerAsync(Office.EventType.DialogParentMessageReceived, messageHandler);
  sendMessage(JSON.stringify({ dialogReady: true }));
});

if ((module as any).hot) {
  (module as any).hot.accept("./components/BasicDialog", () => {
    const NextDialog = BasicDialog;
    render(NextDialog);
  });
  (module as any).hot.accept("./components/WarningDialog", () => {
    const NextDialog = WarningDialog;
    render(NextDialog);
  });
}
