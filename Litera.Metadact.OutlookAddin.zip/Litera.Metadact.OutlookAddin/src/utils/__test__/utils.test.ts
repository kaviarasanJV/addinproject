//**************************************************
//* © 2021 Litera. All Rights Reserved.
//**************************************************

import {
  getRiskLevel,
  getContentRisk,
  isRiskyDomain,
  isExtensionSupported,
  getRiskyEmailAddresses,
  msToSeconds,
  formatSeconds,
} from "../utils";
import translation from "../translation";

const defaultNullProfileFields = {
  builtInProperties: null,
  comments: null,
  customProperties: null,
  customUiXml: null,
  customXml: null,
  dataConnection: null,
  definedNamesComments: null,
  hiddenObjects: null,
  inkAnnotations: null,
  obfuscatedText: null,
  personalInformation: null,
  scenariosComments: null,
  trackedChanges: null,
  vbaCode: null,
  alternativeText: null,
  customViews: null,
  hiddenColumns: null,
  hiddenRows: null,
  hiddenSheets: null,
  oleObjects: null,
  smallText: null,
  thumbnail: null,
  worksheetProperties: null,
  xmlComments: null,
  charts: null,
  definedNames: null,
  footers: null,
  formulas: null,
  headers: null,
  hyperlinks: null,
  links: null,
  pictures: null,
  printerInformation: null,
  scenarios: null,
  databaseQueries: null,
  controls: null,
  bookmarks: null,
  endnotes: null,
  fields: null,
  footnotes: null,
  drawingObjects: null,
  hiddenText: null,
  highlightedText: null,
  mailMergeData: null,
  tableOfContents: null,
  vbaVariables: null,
};
const defaultNullMetadataReport = {
  word: null,
  excel: null,
  powerPoint: null,
  pdf: null,
  pdfA: null,
  xps: null,
  image: null,
};

const defaultProcessingDetails = {
  riskLevel: "",
  processingMode: "",
  totalProcessingTimeMs: 0,
};

describe("Test util functions behavior", () => {
  it("Risk level should be correct", () => {
    // expect(getRiskLevel("")).toBe(translation.low);
    expect(getRiskLevel(undefined)).toBe(translation.low);
    expect(getRiskLevel(null)).toBe(translation.low);
    expect(getRiskLevel({ ...defaultProcessingDetails, riskLevel: 5 })).toBe(translation.low);
    expect(getRiskLevel({ ...defaultProcessingDetails, riskLevel: 30 })).toBe(translation.medium);
    expect(getRiskLevel({ ...defaultProcessingDetails, riskLevel: 80 })).toBe(translation.high);
  });

  it("Content level should be correct", () => {
    // expect(getContentRisk("")).toBe(translation.low);
    expect(getContentRisk(undefined)).toBe(translation.low);
    expect(getContentRisk(null)).toBe(translation.low);

    const metadataReportNull = {
      ...defaultNullMetadataReport,
      word: null,
      excel: null,
    };

    expect(getContentRisk(metadataReportNull)).toBe(translation.low);

    const metadataReportWord = {
      ...defaultNullMetadataReport,
      word: {
        ...defaultNullProfileFields,
        comments: {
          typeId: "",
          friendlyName: "Comments",
          processingTimeMs: 1.6303,
          values: [
            {
              name: "Comment 1",
              value: "Test Comments",
            },
            {
              name: "Comment 2",
              value: "Second comment. ",
            },
          ],
        },
        trackedChanges: {
          typeId: "WordTrackChanges",
          friendlyName: "Tracked Changes",
          processingTimeMs: 49.8373,
          values: [
            {
              name: "Change 1: Inserted",
              value: "Track Changes test",
            },
          ],
        },
      },
    };
    expect(getContentRisk(metadataReportWord)).toBe("Comments, Tracked Changes");

    const metadataReportExcel = {
      ...defaultNullMetadataReport,
      word: null,
      excel: {
        ...defaultNullProfileFields,
        comments: {
          typeId: null,
          friendlyName: "CommentsTest",
          processingTimeMs: 1.6303,
          values: [
            {
              name: "Comment 1",
              value: "Test Comments",
            },
          ],
        },
      },
    };

    expect(getContentRisk(metadataReportExcel)).toBe("CommentsTest");
  });

  it("Specific domain should be filtered", () => {
    expect(isRiskyDomain("", undefined)).toStrictEqual(false);
    expect(isRiskyDomain("test@google.com", undefined)).toStrictEqual(false);
    expect(isRiskyDomain("", [])).toStrictEqual(false);
    expect(isRiskyDomain("", ["google.com"])).toStrictEqual(false);
    expect(isRiskyDomain("test@google.com", ["google.com"])).toStrictEqual(true);
    expect(isRiskyDomain("test@google.com", ["litera.com"])).toStrictEqual(false);
    expect(isRiskyDomain("test@google.com", [])).toStrictEqual(false);
    expect(isRiskyDomain("test@Google.com", ["google.com"])).toStrictEqual(true);
    expect(isRiskyDomain("test@google.com", ["Google.com"])).toStrictEqual(true);
  });

  it("Only supported extension should be shown", () => {
    expect(isExtensionSupported("")).toStrictEqual(false);
    expect(isExtensionSupported("file.doc")).toStrictEqual(true);
    expect(isExtensionSupported("file.pfile")).toStrictEqual(false);
    expect(isExtensionSupported("file.doc.pfile")).toStrictEqual(false);
    expect(isExtensionSupported("file.rtf.pfile")).toStrictEqual(false);
    expect(isExtensionSupported("file.doc1")).toStrictEqual(false);
    expect(isExtensionSupported("file.DOC")).toStrictEqual(true);
    expect(isExtensionSupported("DOC")).toStrictEqual(false);
  });

  it("Return emails which is risky", () => {
    expect(getRiskyEmailAddresses(undefined, undefined)).toStrictEqual([]);
    expect(getRiskyEmailAddresses([], undefined)).toStrictEqual([]);
    expect(getRiskyEmailAddresses(undefined, [])).toStrictEqual([]);
    expect(getRiskyEmailAddresses([], [])).toStrictEqual([]);
    expect(getRiskyEmailAddresses([], ["google.com"])).toStrictEqual([]);
    expect(getRiskyEmailAddresses([{ emailAddress: "test@google.com" }], ["google.com"])).toStrictEqual([
      "test@google.com",
    ]);
  });

  it("Correctly converts milliseconds to seconds", () => {
    expect(msToSeconds(0)).toEqual(0);
    expect(msToSeconds(15000)).toEqual(15);
    expect(msToSeconds(15345)).toEqual(16);
  });

  it("Correctly formats seconds to 'mm:ss' format", () => {
    expect(formatSeconds(0)).toEqual("00:00");
    expect(formatSeconds(4)).toEqual("00:04");
    expect(formatSeconds(24)).toEqual("00:24");
    expect(formatSeconds(87)).toEqual("01:27");
    expect(formatSeconds(1087)).toEqual("18:07");
  });
});
