/*
 * Copyright (c) Microsoft Corporation. All rights reserved. Licensed under the MIT license.
 * See LICENSE in the project root for license information.
 */

import { getConfig } from "../core/Cache";
import { showInformationalMessage } from "../utils/utils";

async function onMessageComposeHandler(event) {
  await getConfig();
  await showInformationalMessage();
  event.completed();
}
async function onAppointmentComposeHandler(event) {
  await getConfig();
  await showInformationalMessage();
  event.completed();
}

// 1st parameter: FunctionName of LaunchEvent in the manifest; 2nd parameter: Its implementation in this .js file.
Office.actions.associate("onMessageComposeHandler", onMessageComposeHandler);
Office.actions.associate("onAppointmentComposeHandler", onAppointmentComposeHandler);
