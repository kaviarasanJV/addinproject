// onSend event should be completed in 5 minutes after it was fired.
// more details: https://docs.microsoft.com/en-us/office/dev/add-ins/outlook/outlook-on-send-addins?tabs=windows#how-does-the-on-send-feature-work
export const ON_SEND_EVENT_EXPIRING_TIME = 300;

// need to have some additional time to make sure that we will have enough time to complete an event
export const ON_SEND_EVENT_EXPIRING_TIME_DELTA = 5;
