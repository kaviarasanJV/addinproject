export interface IProfile {
  name: string;
  id: string;
}
