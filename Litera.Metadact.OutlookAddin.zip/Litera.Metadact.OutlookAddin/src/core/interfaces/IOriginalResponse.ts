export interface IOriginalResponse {
  session: Session;
}

export interface Session {
  id: string;
  createdAt: Date;
  sessionState: string;
}
