export interface IProfileOption {
  caption: string;
  profileName: string;
  id: string;
  name: string;
}
