export interface IPasswordData {
  filename: string;
  password: string;
  lengthBytes: number;
}
