export interface IAttachment {
  riskLevel?: string;
  passwordError?: boolean;
  passwordIncorrect?: boolean;
  error?: boolean;
  password?: string;
  contentRisk?: string;
  errorMsg?: string;
  name: string;
  content?: string;
  contentType?: string;
  id: string;
  sessionId?: string;
  option?: string;
  attachmentType?: string;
  progress?: number;
}
