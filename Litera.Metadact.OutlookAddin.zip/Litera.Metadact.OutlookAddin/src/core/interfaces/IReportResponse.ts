export interface IReportResponse {
  processingDetails: ProcessingDetails;
  originalFile: File;
  modifiedFile: File;
  passwordRequired: boolean;
  metadataReport: MetadataReport;
  processingResult: string;
  nestedFiles: any[];
  warnings: any[];
  errors: any[];
}
export interface PowerPoint {
  builtInProperties: BuiltInProperties;
  comments: AlternativeText;
  customProperties: AlternativeText;
  customUiXml: AlternativeText;
  customXml: AlternativeText;
  hiddenObjects: AlternativeText;
  inkAnnotations: AlternativeText;
  notes: AlternativeText;
  obfuscatedText: AlternativeText;
  offSlideContent: AlternativeText;
  personalInformation: AlternativeText;
  slideAndPresentationTags: AlternativeText;
  vbaCode: AlternativeText;
  alternativeText: AlternativeText;
  animations: AlternativeText;
  hiddenSlides: AlternativeText;
  oleObjects: AlternativeText;
  smallText: AlternativeText;
  thumbnail: AlternativeText;
  unusedMasters: AlternativeText;
  xmlComments: AlternativeText;
  audioFiles: AlternativeText;
  footers: AlternativeText;
  headers: AlternativeText;
  hyperlinks: null;
  moviesMultimedia: null;
}

export interface MetadataReport {
  word: Word;
  excel: Excel;
  powerPoint: PowerPoint;
  pdf?: null;
  pdfA?: null;
  xps?: null;
  image?: null;
}

export interface Word {
  builtInProperties: BuiltInProperties;
  personalInformation: PersonalInformation;
  alternativeText: AlternativeText;
  bookmarks: AlternativeText;
  comments: AlternativeText;
  controls: AlternativeText;
  customProperties: AlternativeText;
  customUiXml: AlternativeText;
  customXml: AlternativeText;
  databaseQueries: AlternativeText;
  endnotes: AlternativeText;
  fields: AlternativeText;
  footers: AlternativeText;
  footnotes: AlternativeText;
  drawingObjects: AlternativeText;
  headers: AlternativeText;
  hiddenObjects: AlternativeText;
  hiddenText: AlternativeText;
  highlightedText: AlternativeText;
  hyperlinks: null;
  inkAnnotations: AlternativeText;
  mailMergeData: AlternativeText;
  oleObjects: AlternativeText;
  pictures: AlternativeText;
  smallText: AlternativeText;
  tableOfContents: AlternativeText;
  thumbnail: AlternativeText;
  trackedChanges: AlternativeText;
  vbaCode: AlternativeText;
  vbaVariables: AlternativeText;
  obfuscatedText: AlternativeText;
  xmlComments: AlternativeText;
}

export interface Excel {
  builtInProperties: BuiltInProperties;
  comments: AlternativeText;
  customProperties: AlternativeText;
  customUiXml: AlternativeText;
  customXml: AlternativeText;
  dataConnection: AlternativeText;
  definedNamesComments: AlternativeText;
  hiddenObjects: AlternativeText;
  inkAnnotations: AlternativeText;
  obfuscatedText: AlternativeText;
  personalInformation: AlternativeText;
  scenariosComments: AlternativeText;
  trackedChanges: AlternativeText;
  vbaCode: AlternativeText;
  alternativeText: AlternativeText;
  customViews: AlternativeText;
  hiddenColumns: AlternativeText;
  hiddenRows: AlternativeText;
  hiddenSheets: AlternativeText;
  oleObjects: AlternativeText;
  smallText: AlternativeText;
  thumbnail: AlternativeText;
  worksheetProperties: AlternativeText;
  xmlComments: AlternativeText;
  charts: AlternativeText;
  definedNames: AlternativeText;
  footers: AlternativeText;
  formulas: AlternativeText;
  headers: AlternativeText;
  hyperlinks: null;
  links: AlternativeText;
  pictures: AlternativeText;
  printerInformation: AlternativeText;
  scenarios: AlternativeText;
}

export interface AlternativeText {
  typeId: string;
  friendlyName: string;
  processingTimeMs: number;
  values: Value[];
}

export interface Value {
  name: string;
  value: string;
}

export interface BuiltInProperties {
  applicationName: AlternativeText;
  applicationVersion: AlternativeText;
  author: AlternativeText;
  category: AlternativeText;
  characterCount: AlternativeText;
  characterCountIncludingSpaces: AlternativeText;
  comments: AlternativeText;
  company: AlternativeText;
  contentProperties: AlternativeText;
  contentStatus: AlternativeText;
  createdDate: AlternativeText;
  documentVersion: null;
  format: null;
  hyperlinks: null;
  hyperlinksChanged: AlternativeText;
  hyperlinksUpToDate: AlternativeText;
  keywords: AlternativeText;
  language: null;
  lastSavedBy: AlternativeText;
  lastPrintDate: null;
  lastSaveTime: null;
  lineCount: AlternativeText;
  manager: null;
  modifiedDate: AlternativeText;
  pageCount: AlternativeText;
  paragraphCount: AlternativeText;
  revisionNumber: AlternativeText;
  scale: AlternativeText;
  security: AlternativeText;
  sharedDocument: AlternativeText;
  subject: AlternativeText;
  template: null;
  title: AlternativeText;
  totalEditingTime: AlternativeText;
  wordCount: AlternativeText;
  typeId: string;
  friendlyName: string;
  processingTimeMs: number;
}

export interface PersonalInformation {
  namesAssociatedWithCommentsOrTrackedChanges: null;
  dateAndTimeAssociatedWithCommentsOrTrackedChanges: null;
  userAddress: null;
  userInitials: null;
  userName: null;
  typeId: string;
  friendlyName: string;
  processingTimeMs: number;
}

export interface File {
  fileDetailsType: string;
  fileName: string;
  lengthBytes: number;
}

export interface ProcessingDetails {
  riskLevel: string | number;
  processingMode: string;
  totalProcessingTimeMs: number;
}
