import { useState, useRef, useEffect } from "react";

import { msToSeconds } from "../utils/utils";
import { ON_SEND_EVENT_EXPIRING_TIME, ON_SEND_EVENT_EXPIRING_TIME_DELTA } from "../const";
import { DialogAction } from "../types";
import { clearCachedSendEventTimestamp, getCachedSendEventTimestamp } from "../core/Cache";

// sets dialog timer if there is a timestamp stored in Outlook roaming settings and
// automatically closes the dialog when timer goes out
const useDialogTimer = (sendMessage: (message: string) => void) => {
  const [timerValue, setTimerValue] = useState<number>(null);
  const intervalRef = useRef(null);

  // on component mount, check if there is a sendEventTimestamp stored in Outlook
  // roaming settings and if it was found, set a dialog life timer.
  // sendEventTimestamp is needed to compensate missing time between onSend event and
  // actual dialog scripts.
  useEffect(() => {
    const sendEventTimestamp = getCachedSendEventTimestamp();

    if (sendEventTimestamp) {
      const shift = msToSeconds(Date.now() - sendEventTimestamp);
      const timerSeconds = ON_SEND_EVENT_EXPIRING_TIME - shift - ON_SEND_EVENT_EXPIRING_TIME_DELTA;

      setTimerValue(timerSeconds);
      intervalRef.current = setInterval(() => {
        setTimerValue((value) => (value > 0 ? value - 1 : value));
      }, 1000);

      clearCachedSendEventTimestamp();
    }

    return () => clearInterval(intervalRef.current);
  }, []);

  useEffect(() => {
    if (timerValue === 0) {
      clearInterval(intervalRef.current);
      sendMessage(JSON.stringify({ action: DialogAction.CloseDialog }));
    }
  }, [timerValue]);

  return timerValue;
};

export default useDialogTimer;
