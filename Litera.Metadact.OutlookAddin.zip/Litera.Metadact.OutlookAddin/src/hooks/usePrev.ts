import { useRef, useEffect } from "react";

// returns the argument's value from previous component render
const usePrev = <T>(value: T): T => {
  const ref = useRef<T>(null);

  useEffect(() => {
    ref.current = value;
  }, [value]);

  return ref.current;
};

export default usePrev;
