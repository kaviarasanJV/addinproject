import * as React from "react";
import { Stack, IStackTokens, TextField, PrimaryButton } from "@fluentui/react";
import translation from "../../utils/translation";
import { getCacheConfig, cacheConfig } from "../../core/Cache";

const smallStackTokens: IStackTokens = {
  childrenGap: "s1",
};

const DataManagementSettings = () => {
  const [value, setValue] = React.useState("");

  React.useEffect(() => {
    (async () => {
      const result = await getCacheConfig();
      setValue(JSON.stringify(result, null, "\t"));
    })();
  });

  const resetConfig = async () => {
    const result = await getCacheConfig();
    setValue(JSON.stringify(result, null, "\t"));
  };

  const saveConfig = () => {
    cacheConfig(value);
  };

  return (
    <Stack tokens={smallStackTokens}>
      <TextField autoAdjustHeight value={value} label={translation.isCurrentlyCahhed} multiline />
      <PrimaryButton text={translation.resetConfig} onClick={resetConfig} />

      <PrimaryButton text={translation.saveConfig} onClick={saveConfig} />
    </Stack>
  );
};

export default DataManagementSettings;
