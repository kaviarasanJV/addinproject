import * as React from "react";
import { FocusZone, FocusZoneDirection, Stack, Toggle, MessageBar, MessageBarType } from "@fluentui/react";
import { getTheme, mergeStyleSets, ITheme } from "@fluentui/react/lib/Styling";
import translation from "../../utils/translation";
import { showInformationalMessage } from "../../utils/utils";
import { setEnableCleaning as setEnableCleaning, getUserEnableCleaning } from "../../core/Cache";

const theme: ITheme = getTheme();
const { palette, fonts } = theme;

const classNames = mergeStyleSets({
  itemCell: {
    margin: "10px 0",
    padding: "16px 12px",
    boxShadow: "0 1.6px 3.6px 0 rgb(0 0 0 / 13%), 0 0.3px 0.9px 0 rgb(0 0 0 / 11%)",
    backgroundColor: "white",
  },
  itemName: [
    fonts.mediumPlus,
    {
      marginBottom: "8px",
    },
  ],
  settingTitle: {
    color: palette.teal,
    lineHeight: "15px",
    padding: "10px 15px 0",
  },
  list: {
    padding: "0 15px 15px",
  },
  itemDescription: [
    fonts.medium,
    {
      width: "224px",
      marginBottom: "8px",
    },
  ],
  itemWarning: {
    marginRight: "10px",
  },
});

interface ISettingsProps {
  allowToSkipCleaning: boolean;
}

interface ISettingItemsProps {
  name: string;
  description: string;
  warning?: string;
}

const settingsItems: ISettingItemsProps[] = [
  {
    name: translation.cleaning,
    description: translation.cleaningDescription,
    warning: translation.notPermittedCleaning,
  },
];

const Settings: React.FunctionComponent<ISettingsProps> = ({ allowToSkipCleaning }: ISettingsProps) => {
  const [isCleaning, setIsCleaning] = React.useState(true);
  
  const onCleaningButtonToggled = async (checked: boolean) => {
    setIsCleaning(checked);
    await setEnableCleaning(checked);
    await showInformationalMessage();
  };

  React.useEffect(() => {
    (async () => {
      const result = await getUserEnableCleaning();
      setIsCleaning(result);
    })();
  }, []);

  const onRenderCells = (items: ISettingItemsProps[]) =>
    items.map(function cellComponent(item, index) {
      return (
        <div className={classNames.itemCell} data-is-focusable={true} key={index}>
          <div className={classNames.itemName}>{item.name}</div>
          <div className={classNames.itemDescription}>{item.description}</div>
          <Stack horizontal horizontalAlign="end" verticalAlign="center">
            {!allowToSkipCleaning && (
              <MessageBar
                messageBarType={MessageBarType.severeWarning}
                isMultiline={true}
                className={classNames.itemWarning}
              >
                {item.warning}
              </MessageBar>
            )}
            <Toggle
              checked={isCleaning}
              onText={translation.cleaningOn}
              offText={translation.cleaningOff}
              disabled={!allowToSkipCleaning}
              onClick={() => onCleaningButtonToggled(!isCleaning)}
            />
          </Stack>
        </div>
      );
    });

  const [items, setItems] = React.useState(onRenderCells(settingsItems));

  React.useEffect(() => {
    setItems(onRenderCells(settingsItems));
  }, [isCleaning]);

  return (
    <FocusZone direction={FocusZoneDirection.vertical}>
      <div className={classNames.settingTitle}>Settings</div>
      <div className={classNames.list}>{items}</div>
    </FocusZone>
  );
};

export default Settings;
