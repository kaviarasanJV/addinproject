import * as React from "react";
import { Spinner, SpinnerSize, Stack, Pivot, PivotItem } from "@fluentui/react";
import translation from "../../utils/translation";
import Settings from "./Settings";
import DataManagementSettings from "./DataManagementSettings";
import { getTheme, mergeStyleSets } from "@fluentui/react/lib/Styling";
import { Config } from "../../types";

const theme = getTheme();
const classNames = mergeStyleSets({
  pane: {
    maxWidth: 400,
    borderTop: "1px solid " + theme.palette.neutralLight,
    height: "100%",
    overflowX: "hidden",
    overflowY: "auto",
    background: theme.palette.neutralLighter,
  },
});

export interface AppProps {
  isOfficeInitialized: boolean;
  config: Config;
}

export const App = ({ isOfficeInitialized, config }: AppProps) => {
  const [selectedKey, setSelectedKey] = React.useState("Settings");

  const handleLinkClick = (item?: PivotItem) => {
    if (item) {
      setSelectedKey(item.props.itemKey!);
    }
  };

  const getTabId = (itemKey: string) => {
    return `Pivot_${itemKey}`;
  };

  if (!isOfficeInitialized) {
    return (
      <Stack verticalFill horizontalAlign="center" verticalAlign="center">
        <Spinner label={translation.dialogLoading} size={SpinnerSize.large} />
      </Stack>
    );
  }

  const showTab = (tabId: string) => {
    switch (tabId) {
      case "Settings":
        return <Settings allowToSkipCleaning={config.allowToSkipCleaning}></Settings>;
      case "DataManagementSettings":
        return <DataManagementSettings></DataManagementSettings>;
      default:
        return "";
    }
  };

  return (
    <Stack verticalFill>
      <Stack horizontal horizontalAlign="end">
        <Pivot
          aria-label="Pivot litera Add-in"
          selectedKey={selectedKey}
          onLinkClick={handleLinkClick}
          headersOnly={true}
          getTabId={getTabId}
        >
          <PivotItem itemIcon="Settings" itemKey="Settings" />

          {config.developerMode && <PivotItem itemIcon="DataManagementSettings" itemKey="DataManagementSettings" />}
        </Pivot>
      </Stack>

      <div aria-labelledby={getTabId(selectedKey)} className={classNames.pane} role="tabpanel">
        {showTab(selectedKey)}
      </div>
    </Stack>
  );
};
